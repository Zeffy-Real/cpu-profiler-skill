===============================================================================
  压缩包A - 可运行测试 + 执行结果
  CPU Profiler Skill - Test Suite with Execution Results
===============================================================================

【压缩包内容】

  tests/
    ├── conftest.py          - pytest fixtures（测试夹具配置）
    ├── test_api.py          - API接口测试（10个测试）
    ├── test_collector.py    - 采集器模块测试（26个测试）
    └── test_flamegraph.py   - 火焰图生成测试（9个测试）

  src/
    ├── __init__.py
    ├── core/
    │   ├── __init__.py
    │   ├── config.py        - 配置管理类
    │   └── flamegraph.py    - 火焰图生成器
    ├── collector/
    │   ├── __init__.py
    │   ├── rotator.py       - 文件轮转与索引管理
    │   └── daemon.py        - 采集守护进程
    └── api/
        ├── __init__.py
        ├── models.py        - Pydantic数据模型
        └── server.py        - FastAPI REST服务

  conftest.py               - 根级pytest配置
  pytest.ini                - pytest配置文件
  requirements.txt          - Python依赖列表
  test_results.txt          - 测试执行结果（45 passed, 1 warning in 16.24s）
  README_HOW_TO_RUN.txt     - 本说明文件

【运行环境要求】

  - Python 3.12+
  - pytest >= 7.0
  - httpx >= 0.24
  - fastapi >= 0.100
  - uvicorn[standard] >= 0.20
  - pydantic >= 2.0
  - Linux环境（需要perf工具用于集成测试）

【运行方法】

  1. 安装依赖：
     pip install -r requirements.txt

  2. 运行全部测试：
     pytest -v --tb=short

  3. 运行特定模块测试：
     pytest tests/test_collector.py -v
     pytest tests/test_api.py -v
     pytest tests/test_flamegraph.py -v

  4. 仅运行单元测试（跳过需要perf的集成测试）：
     pytest -v -k "not real_perf and not once_mode and not flamegraph_generation"

【测试结构说明】

  test_collector.py (26个测试):
    - TestFileRotator: 文件名生成、时间戳解析、过期清理、磁盘检查、
      索引读写、原子写入、去重（16个测试）
    - TestProfilerDaemon: 初始化、命令构建、dry run、信号处理、
      可中断睡眠、单次采集（10个测试）

  test_api.py (10个测试):
    - TestHealth: 健康检查端点
    - TestSlices: 切片查询（空数据、有数据、时间过滤）
    - TestFlamegraph: 火焰图生成（未找到、文件缺失、成功、无效范围、无切片、范围查询）

  test_flamegraph.py (9个测试):
    - TestFlameGraphGeneration: 完整管线、缺失文件、自定义参数、空范围
    - TestFlameGraphUnit: 初始化参数、默认值、工具检查、索引查询、失败切片过滤

【执行结果摘要】

  ======================== 45 passed, 1 warning in 16.24s ========================

  完整执行结果见 test_results.txt 文件。

【注意事项】

  - 依赖perf/flamegraph工具的集成测试在缺少这些工具时会自动跳过
  - 测试使用临时目录，不会影响系统数据
  - conftest.py中的fixtures会自动设置DATA_DIR环境变量避免权限问题

===============================================================================
